<?php

return [
    'apikey' => env('MC_KEY'),
];
